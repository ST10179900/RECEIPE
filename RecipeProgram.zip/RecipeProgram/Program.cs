﻿public class MainClass
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter recipe details:");

        Console.Write("Recipe Name: ");
        string name = Console.ReadLine();

        Console.Write("Number of Ingredients: ");
        int numIngredients = int.Parse(Console.ReadLine());

        Console.Write("Number of Steps: ");
        int numSteps = int.Parse(Console.ReadLine());

        Recipe recipe = new Recipe(name, numIngredients, numSteps);

        for (int i = 0; i < numIngredients; i++)
        {
            Console.WriteLine("Enter details for Ingredient " + (i + 1) + ":");
            Console.Write("Name: ");
            string ingredientName = Console.ReadLine();
            Console.Write("Quantity: ");
            double quantity = double.Parse(Console.ReadLine());
            Console.Write("Unit of Measurement: ");
            string unit = Console.ReadLine();

            recipe.AddIngredient(i, ingredientName, quantity, unit);
        }

        for (int i = 0; i < numSteps; i++)
        {
            Console.WriteLine("Enter details for Step " + (i + 1) + ":");
            Console.Write("Description: ");
            string stepDescription = Console.ReadLine();

            recipe.AddStep(i, stepDescription);
        }

        Console.WriteLine("Recipe Details:");
        NewMethod(recipe);
    }

    private static void NewMethod(Recipe recipe)
    {
        recipe.PrintRecipe();
    }
}
