﻿internal class Recipe
{
    private string? name;
    private int numIngredients;
    private int numSteps;

    public Recipe(string? name, int numIngredients, int numSteps)
    {
        this.name = name;
        this.numIngredients = numIngredients;
        this.numSteps = numSteps;
    }

    internal void AddIngredient(int i, string? ingredientName, double quantity, string? unit)
    {
        throw new NotImplementedException();
    }

    internal void AddStep(int i, string? stepDescription)
    {
        throw new NotImplementedException();
    }

    internal void PrintRecipe()
    {
        throw new NotImplementedException();
    }
}